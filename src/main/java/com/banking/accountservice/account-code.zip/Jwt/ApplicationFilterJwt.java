/*
 * package com.banking.accountservice.Jwt;
 * 
 * import java.io.IOException;
 * 
 * import org.springframework.beans.factory.annotation.Autowired;
 * import org.springframework.security.authentication.
 * UsernamePasswordAuthenticationToken;
 * import org.springframework.security.core.context.SecurityContextHolder;
 * import org.springframework.security.core.userdetails.UserDetails;
 * import org.springframework.security.core.userdetails.UserDetailsService;
 * import org.springframework.security.web.authentication.
 * WebAuthenticationDetailsSource;
 * import org.springframework.stereotype.Component;
 * import org.springframework.web.filter.OncePerRequestFilter;
 * 
 * import jakarta.servlet.FilterChain;
 * import jakarta.servlet.ServletException;
 * import jakarta.servlet.http.HttpServletRequest;
 * import jakarta.servlet.http.HttpServletResponse;
 * import lombok.extern.slf4j.Slf4j;
 * 
 * @Component
 * 
 * @Slf4j
 * public class ApplicationFilterJwt extends OncePerRequestFilter {
 * 
 * @Autowired
 * private JwtUtils jwtUtils;
 * 
 * @Autowired
 * private UserDetailsService userDetailsService;
 * 
 * @Override
 * protected void doFilterInternal(HttpServletRequest request,
 * HttpServletResponse response, FilterChain filterChain)
 * throws ServletException, IOException {
 * 
 * log.debug("AuthTokenFilter called for uri: {}", request.getRequestURI());
 * 
 * try {
 * String jwt = parseJwt(request);
 * if (jwt != null && jwtUtils.validateJwtToken(jwt)) {
 * String username = jwtUtils.getUsernameFromJwtToken(jwt);
 * 
 * UserDetails userDetails = userDetailsService.loadUserByUsername(username);
 * 
 * UsernamePasswordAuthenticationToken authentication = new
 * UsernamePasswordAuthenticationToken(userDetails, null,
 * userDetails.getAuthorities());
 * 
 * authentication.setDetails(new
 * WebAuthenticationDetailsSource().buildDetails(request));
 * SecurityContextHolder.getContext().setAuthentication(authentication);
 * }
 * 
 * } catch (Exception e) {
 * log.error("Cannot set user authentication: {}", e);
 * }
 * filterChain.doFilter(request, response);
 * 
 * }
 * 
 * private String parseJwt(HttpServletRequest request) {
 * String jwt = jwtUtils.getJwtFromHeader(request);
 * log.debug("Authentication filder: {}", jwt);
 * return jwt;
 * }
 * 
 * }
 */
