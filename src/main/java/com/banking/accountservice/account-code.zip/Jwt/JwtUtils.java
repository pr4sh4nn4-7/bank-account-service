/*
 * package com.banking.accountservice.Jwt;
 * 
 * import java.security.Key;
 * import java.util.Date;
 * 
 * import javax.crypto.SecretKey;
 * 
 * import org.springframework.beans.factory.annotation.Value;
 * import org.springframework.security.core.userdetails.UserDetails;
 * import org.springframework.stereotype.Component;
 * 
 * import io.jsonwebtoken.ExpiredJwtException;
 * import io.jsonwebtoken.Jwts;
 * import io.jsonwebtoken.MalformedJwtException;
 * import io.jsonwebtoken.UnsupportedJwtException;
 * import io.jsonwebtoken.io.Decoders;
 * import io.jsonwebtoken.security.Keys;
 * import jakarta.servlet.http.HttpServletRequest;
 * import lombok.extern.slf4j.Slf4j;
 * 
 * @Component
 * 
 * @Slf4j
 * public class JwtUtils {
 * 
 * @Value("${spring.app.JWT_SECRET}")
 * private String jwtSecret;
 * 
 * @Value("${spring.app.jwtExpirationMs}")
 * private int jwtExpirationMs;
 * 
 * public String getJwtFromHeader(HttpServletRequest request) {
 * String bearerToken = request.getHeader("Authorization");
 * log.info("Authorization header: {}", bearerToken);
 * if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
 * return bearerToken.substring(7);
 * 
 * }
 * return null;
 * }
 * 
 * public String generateTokenFromUsername(UserDetails userDetails) {
 * String username = userDetails.getUsername();
 * return Jwts.builder()
 * .subject(username)
 * .issuedAt(new Date())
 * .expiration(new Date(new Date().getTime() + jwtExpirationMs))
 * .signWith(key())
 * .compact();
 * 
 * }
 * 
 * public String getUsernameFromJwtToken(String token) {
 * return Jwts.parser().verifyWith((SecretKey)
 * key()).build().parseSignedClaims(token)
 * .getPayload().getSubject();
 * 
 * }
 * 
 * private Key key() {
 * return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
 * 
 * }
 * 
 * public boolean validateJwtToken(String authToken) {
 * try {
 * Jwts.parser().verifyWith((SecretKey)
 * key()).build().parseSignedClaims(authToken);
 * return true;
 * 
 * } catch (MalformedJwtException e) {
 * log.error("Invalid jwt token: {}", e.getMessage());
 * } catch (ExpiredJwtException e) {
 * log.error("Jwt token is expired: {}", e.getMessage());
 * } catch (UnsupportedJwtException e) {
 * log.error("Jwt token is unsupported: {}", e.getMessage());
 * 
 * } catch (IllegalArgumentException e) {
 * log.error("Jwt claims string is empty: {}", e.getMessage());
 * }
 * return false;
 * 
 * }
 * 
 * }
 */
